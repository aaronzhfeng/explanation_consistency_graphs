"""
ECG: Explanation-Consistency Graphs

A framework for training data debugging using LLM-generated explanations.
Detects mislabeled examples by computing neighborhood surprise in 
explanation embedding space.

Core modules:
- data: Dataset loading and noise injection
- explain_llm: LLM explanation generation with schema constraints
- embed_graph: kNN graph construction over explanation embeddings
- signals: ECG signal computation (neighborhood surprise, etc.)
- baselines: Baseline methods (Cleanlab, Input kNN, etc.)
- eval: Detection and evaluation metrics
- clean: Data cleaning strategies

References:
- Cleanlab: https://github.com/cleanlab/cleanlab
- AUM: https://github.com/asappresearch/aum
- Neural Relation Graph: https://github.com/snu-mllab/Neural-Relation-Graph
- WANN: https://github.com/francescodisalvo05/wann-noisy-labels
"""

from .data import (
    NoiseConfig,
    ArtifactConfig,
    NoisyDataset,
    create_noisy_dataset,
    inject_random_noise,
)

from .explain_llm import (
    StructuredExplanation,
    ExplanationGenerator,
    generate_batch_with_stability,
    explanations_to_embeddings,
)

from .embed_graph import (
    GraphConfig,
    ExplanationGraph,
    build_explanation_graph,
)

from .signals import (
    ECGSignals,
    compute_neighborhood_surprise,
    compute_all_signals,
)

from .baselines import (
    BaselineResults,
    compute_cleanlab_scores,
    compute_input_knn_scores,
    compute_llm_mismatch_scores,
)

from .eval import (
    DetectionMetrics,
    compute_detection_metrics,
    compute_precision_recall_at_k,
    print_detection_summary,
)

from .clean import (
    CleaningConfig,
    CleaningResult,
    clean_dataset,
)

from .train_classifier import (
    TrainingConfig,
    TrainingDynamics,
    train_classifier,
)

__version__ = "1.0.0"
__all__ = [
    # Data
    "NoiseConfig",
    "ArtifactConfig", 
    "NoisyDataset",
    "create_noisy_dataset",
    "inject_random_noise",
    # Explanations
    "StructuredExplanation",
    "ExplanationGenerator",
    "generate_batch_with_stability",
    "explanations_to_embeddings",
    # Graph
    "GraphConfig",
    "ExplanationGraph",
    "build_explanation_graph",
    # Signals
    "ECGSignals",
    "compute_neighborhood_surprise",
    "compute_all_signals",
    # Baselines
    "BaselineResults",
    "compute_cleanlab_scores",
    "compute_input_knn_scores",
    "compute_llm_mismatch_scores",
    # Evaluation
    "DetectionMetrics",
    "compute_detection_metrics",
    "compute_precision_recall_at_k",
    "print_detection_summary",
    # Cleaning
    "CleaningConfig",
    "CleaningResult",
    "clean_dataset",
    # Training
    "TrainingConfig",
    "TrainingDynamics",
    "train_classifier",
]
