# ECG: Explanation-Consistency Graphs

**Supplementary Code for ACL 2026 Submission**

> Anonymous submission — do not distribute

---

## Overview

This repository contains the implementation of **Explanation-Consistency Graphs (ECG)** for training data debugging. ECG detects mislabeled examples by computing neighborhood surprise in LLM explanation embedding space.

**Key result**: ECG achieves 0.832 AUROC on artifact-aligned noise where Cleanlab collapses to 0.107, while remaining competitive on random noise (0.943 vs 0.977).

---

## Repository Structure

```
submission_code/
├── src/ecg/                    # Core implementation
│   ├── __init__.py             # Package exports
│   ├── data.py                 # Dataset loading & noise injection
│   ├── train_classifier.py     # Classifier training & AUM
│   ├── explain_llm.py          # LLM explanation generation
│   ├── embed_graph.py          # kNN graph construction
│   ├── signals.py              # ECG signal computation
│   ├── baselines.py            # Baseline methods (Cleanlab, etc.)
│   ├── eval.py                 # Detection metrics
│   └── clean.py                # Data cleaning strategies
│
├── scripts/                    # Experiment scripts
│   ├── experiment_ensemble.py  # Main artifact-aligned experiment
│   ├── experiment_random_noise.py  # Random noise experiment
│   └── run_experiment.py       # Full pipeline runner
│
├── configs/
│   └── default.yaml            # Default hyperparameters
│
├── outputs/results/            # Experiment results
│   ├── artifact_noise_main.json    # Main (25k, 10%)
│   ├── random_noise_main.json      # Random noise (25k, 10%)
│   ├── downstream_cleaning.json    # Downstream eval
│   ├── artifact_noise_5pct.json    # Noise rate: 5%
│   ├── artifact_noise_20pct.json   # Noise rate: 20%
│   ├── random_noise_5pct.json      # Random 5%
│   ├── random_noise_20pct.json     # Random 20%
│   ├── artifact_noise_5k.json      # Dataset: 5k
│   ├── artifact_noise_10k.json     # Dataset: 10k
│   ├── llm_qwen3_1.7B.json         # LLM: 1.7B
│   └── llm_qwen3_14B.json          # LLM: 14B
│
├── requirements.txt            # Python dependencies
└── README.md                   # This file
```

---

## Installation

```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### Requirements

- Python 3.10+
- CUDA-capable GPU (for LLM inference)
- ~16GB GPU memory (for Qwen3-8B)

---

## Running Experiments

### Main Experiment (Artifact-Aligned Noise)

```bash
python scripts/experiment_ensemble.py --noise_rate 0.10 --dataset_size 25000
```

### Random Noise Experiment

```bash
python scripts/experiment_random_noise.py --noise_rate 0.10 --dataset_size 25000
```

### Sensitivity Analysis

```bash
# Noise rate sensitivity
python scripts/experiment_ensemble.py --noise_rate 0.05
python scripts/experiment_ensemble.py --noise_rate 0.20

# Dataset size
python scripts/experiment_ensemble.py --dataset_size 5000
python scripts/experiment_ensemble.py --dataset_size 10000

# LLM size ablation
python scripts/experiment_ensemble.py --model Qwen/Qwen3-1.7B --dataset_size 10000
python scripts/experiment_ensemble.py --model Qwen/Qwen3-14B --dataset_size 10000
```

---

## Core Algorithm

### Explanation kNN (Primary Method)

```python
from ecg.explain_llm import ExplanationGenerator
from ecg.embed_graph import build_explanation_graph
from ecg.signals import compute_neighborhood_surprise

# 1. Generate structured explanations
generator = ExplanationGenerator(model_name="Qwen/Qwen3-8B")
explanations = generator.generate_batch(sentences)

# 2. Embed explanations and build kNN graph
embeddings = explanations_to_embeddings(explanations)
graph = build_explanation_graph(embeddings, k=15)

# 3. Compute neighborhood surprise
scores = compute_neighborhood_surprise(graph, observed_labels)

# High scores indicate likely mislabeled examples
```

### Key Insight

LLM explanations capture *why* a label should apply. When labels are wrong, explanations become inconsistent with neighbors in embedding space — even when classifier confidence remains high due to spurious correlations.

---

## Results Summary

### Table 1: Main Results (10% Noise)

| Method | Artifact AUROC | Random AUROC |
|--------|----------------|--------------|
| **Explanation kNN** | **0.832** | 0.943 |
| Input kNN | 0.671 | 0.880 |
| Cleanlab | 0.107 | **0.977** |
| LLM Mismatch | 0.724 | 0.929 |

### Key Findings

1. **+24% improvement** over Input kNN on artifact noise
2. **Robustness**: Works across noise regimes (Cleanlab fails on artifacts)
3. **Downstream impact**: Removing top 2% flagged → +0.57% accuracy

---

## Hyperparameters

See `configs/default.yaml` for all settings. Key parameters:

| Parameter | Value | Description |
|-----------|-------|-------------|
| LLM | Qwen/Qwen3-8B | Explanation generator |
| Embedding | all-MiniLM-L6-v2 | Sentence encoder |
| k | 15 | kNN neighbors |
| Temperature | 0.07 | Softmax temperature |

---

## License

This code is provided for review purposes only. License will be added upon acceptance.

---

*Anonymous ACL 2026 Submission*

